# Overleaf 上传说明

在 Overleaf 选择 New Project → Upload Project，上传本ZIP；主文件为根目录 main.tex，编译器选 pdfLaTeX。图形为嵌入字体的矢量PDF，另附SVG供编辑。IEEEtran.cls随包提供，正文使用标准IEEE Conference排版。

本版为2026-11-11统一图表样式的最终稿。老师批准的摘要、八位作者及实验数值保留。前四共同第一作者；王聪和郑杰鑫共同通讯。作者姓名链接到各自ORCID。

本项目已在服务器用兼容pdfLaTeX实际编译；14页文本与渲染和交付PDF一致。没有声称已登录或在Overleaf云端编译。重新绘图的完整脚本与CSV另在paper_source.zip；本ZIP仅保留直接编译需要的源文件。CMT上传正式PDF，不上传本ZIP。
